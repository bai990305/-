# MySQL优化笔记(optimization)

## 关于MySQL的知识

300万条导入导出在**200s**左右1000万**10分钟**左右

char是**固定长度要用空格补齐**,varchar是**指定长度不超过就可**

int默认长度**18**

数据库是**文件集**

数据完整性由**域完整性、实体完整性、参照完整性**

红黑树是**平衡二叉树**，数据大导致h过多解决办法是**横向扩展**

ACID 事务的四个原则 **原子性、一致性、隔离性、持久性**

事务的四个隔离级别：未提交读、已提交读(默认)、可重复读、可串行化

https://www.cnblogs.com/Kevin-ZhangCG/p/9038371.html

BASE 原则 跟ACID相反 要求牺牲一致性(最终达到一致性)，达到可用性\

**基本可用、软状态、最终一致性**

CAP定理 **分区容错 一致性 可用性** 无法同时满足，必定会产生分区容错。

集群：有多个一样的 个体组成的部署在不同服务器，负载均衡

分布式:一个个体拆成多个模块部署在多个应用中由他们相互调用

## MySQL优化

### MySQL优化的方向

#### 硬件级别

硬件级别包括：磁盘寻找、磁盘读写、cpu(计算)、存储带宽(cpu缓存)

#### 数据库级别

数据库级别:导致数据库应用最高效的因素就是它的基本设计:

表结构是否正确、正确的设置索引达到查询高效、对于不同请款选择不同的存储引擎，每张表是否具有适当的行格式、应用程序是否使用适当的锁策略、所有缓存区域使用的大小是否正确

### MySQL执行查询的流程

![59697721162](D:\wangcaiAccount\笔记\图片\1596977211624.png)

通过tcp协议通信，将SQL语句通过hash算法得出hash值(多一个空格的值都不一样)作为key与缓存查找，若有直接返回数据，没有通过解析器查找关键字是否有错误，没有则解析成解析树，通过预处理器检查是否有语句歧义，没有则形成新的解析树，通过优化器形成执行计划交给引擎来查询

#### 缓存

```mysql
show variables like '%query_cache%'//查看缓存系统参数

SET GLOBAL query_cache_size=134217728 //设置缓存大小

SHOW STATUS like '%Qcache%' //查看缓存状态

SET global query_cache_type = 2 //开启查询缓存(命令无效)

Qcache_queries_in_cache 当前缓存中数量
Qcache_insert           插入到缓存中总数
Qcache_hits             缓存命中数
Qcache_lowmem_prunes    由于缓存较小,从缓存中删除的个数
```

### mysql引擎

#### MyISAM

MyISAM不支持外键和事务

MyISAM的数据库存储文件集:frm表结构,.MYD是数据文件.MYI是索引文件

(非聚集索引)

#### InnoDB

innodb的数据库存储文件集:opt存储数据库编码.frm表结构.idb数据及索引 二进制物理文件(聚集索引)

![59723238445](D:\wangcaiAccount\笔记\图片\1597232384455.png)

![59704599145](D:\wangcaiAccount\笔记\图片\1597045991459.png)

![59704675454](D:\wangcaiAccount\笔记\图片\1597046754540.png)

#### InnoDB与MyISAM区别

![59704690931](D:\wangcaiAccount\笔记\图片\1597046909315.png)

![59704697217](D:\wangcaiAccount\笔记\图片\1597046972179.png)

#### 其他引擎

- Memory(内存)
- NDBCLuster(集群)
- RCHIVE(过期数据)
- MRG_MYISAM(增强MYISAM)
- BLACKHOLE(只进不出)
- CSV(导出报表)
- PERFORMANCE_SCHEMA(收集系统参数)

#### 关于引擎的命令

```mysql
show create table table_name //查看数据库表所用的存储引擎

create table table_name engine = engine_name //创建表指定引擎

alter table table_name engine = engine_name //修改表的存储引擎
```

## SQL优化

#### 调优思路

![59706022218](D:\wangcaiAccount\笔记\图片\1597060222183.png)

#### MySQL日志类别

- 错误日志(回滚)
- 二进制日志(主从)：记录修改数据或有可能引起数据变更的MySQL语句
- 通用查询日志(记录查询等信息)
- 慢查询日志

#### 执行计划explain

在mysql中可以通过explain关键字模拟执行优化器，从而知道mysql是如何处理SQL语句的。

##### explain各列解析

![59711259978](D:\wangcaiAccount\笔记\图片\1597112599786.png)

![59711267603](D:\wangcaiAccount\笔记\图片\1597112676037.png)

**slect_type**:

- **SIMPLE**：简单查询，只要不是子查询和union都属于简单查询
- **PRIMARY** ：复杂查询的最外层查询
- **DERIVED**：from从句中子查询
- **SUBQUERY** ：where从句中的子查询
- **UNION** ：包含查询子句
- **UNIONRESULT**：包含查询连接结果

![59711303775](D:\wangcaiAccount\笔记\图片\1597113037752.png)

**table**:查询的表名

**partitions**:显示查询即将访问的分区名

![59711546000](D:\wangcaiAccount\笔记\图片\1597115460004.png)

![59711573339](D:\wangcaiAccount\笔记\图片\1597115733398.png)

![59711680869](D:\wangcaiAccount\笔记\图片\1597116808692.png)

**possible_keys**:可能用到的索引

**key**:已经用到的索引

**key_len**：索引最大长度，索引使用的字节数

**ref**:显示索引哪一列被使用了

**rows**:大致估算找到所需记录所要读取的行数

**filtered**:条件过滤出的条数占所有条数的百分比估计值 rows*filtered/100估算出将要进行连接的行数

#### 索引

索引是帮助MySQL高效获取数据的**排好序的数据结构**

www.cs.usfca.edu

创建索引可以大大提高查询性能，不使用索引会从第一行开始查询，使用索引可以更快速找到数据

##### B+树

![59720798671](D:\wangcaiAccount\笔记\图片\1597207986713.png)

##### 索引的优点与缺点

![59713235062](D:\wangcaiAccount\笔记\图片\1597132350627.png)

![59713261450](D:\wangcaiAccount\笔记\图片\1597132614505.png)

##### 索引分类

单列索引、组合索引、全文索引

![59713320383](D:\wangcaiAccount\笔记\图片\1597133203831.png)

![59713322198](D:\wangcaiAccount\笔记\图片\1597133221987.png)

```mysql
create index index_name on table_name(column(length))//创建索引
show index from table_name //展示所有索引
drop index index_name on table_name//删除索引
create unique index index_name on table_name(column(length))//创建唯一索引
create fulltext index index_name on table_name(column(length))//创建全文索引
```

组合索引：顺序有区别，用的越多的在左边

![59723453600](D:\wangcaiAccount\笔记\图片\1597234536006.png)

查找联合索引的时候必须要从左到右,否则不会触发索引。